package com.tesis.v1.rest;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;

import com.tesis.builder.UsuarioColaboradorTestBuild;
import com.tesis.builder.UsuarioTestBuild;
import com.tesis.v1.domain.Proyecto;
import com.tesis.v1.service.ProyectoService;

@SpringBootTest
@Rollback(false)
@TestMethodOrder(OrderAnnotation.class)
class ProyectosServiceTest {

	private final static Logger log = LoggerFactory.getLogger(ProyectosServiceTest.class);
	@Autowired
	ProyectoService proyectoService;

	UsuarioTestBuild usuarioBuild;
	UsuarioColaboradorTestBuild colaboradorBuild;

	@Test
	@Order(1)
	void save() throws Exception {
		/*
		 * email@test.com.co springTst@test.com.co
		 */
		Proyecto proyecto = new Proyecto();
		proyecto.setNombre("Test new  Proyecto Srping");
		proyecto.setDescripcion("DESCRIPCION newTEST SPIRNG");
		proyecto.setAdmin("fallo@test.com.co");
		proyectoService.save(proyecto);

	}

	@Test
	@Order(2)
	void findById() throws Exception {
		Optional<Proyecto> proyectosOp = proyectoService.findById(2);
		if (proyectosOp.isEmpty()) {
			fail("No hay registros asi que paila");

		} else {
			Proyecto proyecto = proyectosOp.get();
			log.info("Id FASE PROYECTO : " + proyecto.getIdproyecto().toString());
			log.info("Nombre del proyecto : " + proyecto.getNombre());
			log.info("Descripcion del proyecto: " + proyecto.getDescripcion());

		}
	}

	@Test
	@Order(3)
	void update() throws Exception {
		Proyecto proyecto = new Proyecto();
		proyecto.setIdproyecto(1);
		proyecto.setAdmin("email@test.com.co");
		proyecto.setNombre("Test update Proyecto Srping");
		proyecto.setDescripcion("DESCRIPCION update TEST SPIRNG");
		// proyectoService.save(proyecto);
		proyectoService.update(proyecto);
	}

	@Test
	@Order(4)
	void findAll() throws Exception {
		for (Proyecto proyecto : proyectoService.findAll()) {
			log.info("Id FASE PROYECTO : " + proyecto.getIdproyecto().toString());
			log.info("Nombre del proyecto : " + proyecto.getNombre());
			log.info("Descripcion del proyecto: " + proyecto.getDescripcion());
			// log.info("Descripcion del proyecto: "+ proyecto.get);

		}
	}

	@Test
	@Order(6)
	void BuscarParticipaciones() throws Exception {
		colaboradorBuild = new UsuarioColaboradorTestBuild();
		String correoString = colaboradorBuild.getEmail();
		log.info("\n Usuario : " + correoString + "\n");
		List<Proyecto> proyectos = proyectoService.BuscarParticipaciones(correoString);

		assertFalse(proyectos.isEmpty(), "NO hay proyecto");
		for (Proyecto proyecto : proyectos) {
			log.info("------");
			log.info("Id FASE PROYECTO : " + proyecto.getIdproyecto().toString());
			log.info("Nombre del proyecto : " + proyecto.getNombre());
			log.info("Descripcion del proyecto: " + proyecto.getDescripcion());

		}

	}

	@Test
	@Order(7)
	void findByEmail() throws Exception {
		usuarioBuild = new UsuarioTestBuild();
		String correoString = usuarioBuild.getEmail();
		log.info("\n Usuario : " + correoString + "\n");
		List<Proyecto> proyectos = proyectoService.findByEmail(correoString);
		assertFalse(proyectos.isEmpty());
		for (Proyecto proyecto : proyectos) {
			log.info("------");
			log.info("Id FASE PROYECTO : " + proyecto.getIdproyecto().toString());
			log.info("Nombre del proyecto : " + proyecto.getNombre());
			log.info("Descripcion del proyecto: " + proyecto.getDescripcion());

		}
	}

	@Test
	@Order(5)
	void delete() throws Exception {
		proyectoService.deleteById(7);

	}
}
